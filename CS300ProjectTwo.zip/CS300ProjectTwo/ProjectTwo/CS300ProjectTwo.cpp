/*
 * CS300ProjectTwo.cpp
 *
 *  Created on: Dec 8, 2023
 *      Author: veronicaguzman
 *      CS 300
 */

// Header files for input/output operations, file handling, string streams, containers, and algorithms
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <map>
#include <algorithm>

// Class representing a Course with course number, title, and prerequisites
class Course {
public:
    std::string courseNumber; // Course number
    std::string courseTitle; // Course title
    std::vector<std::string> prerequisites; // Prerequisite courses

    // Constructor to initialize Course object
    Course(const std::string& number, const std::string& title, const std::vector<std::string>& prereqs)
        : courseNumber(number), courseTitle(title), prerequisites(prereqs) {}
};

// Function to split a string by a delimiter and return a vector of tokens
std::vector<std::string> split(const std::string& str, char delimiter) {
    std::vector<std::string> tokens; // Vector to store tokens
    std::string token;
    std::istringstream tokenStream(str);
    while (std::getline(tokenStream, token, delimiter)) {
        tokens.push_back(token); // Store each token in the vector
    }
    return tokens; // Return the vector of tokens
}

// Function to trim leading and trailing whitespaces from a string
std::string trim(const std::string& str) {
    const auto strBegin = str.find_first_not_of(" \t"); // Find first non-whitespace character
    if (strBegin == std::string::npos)
        return ""; // Return an empty string if there's no content

    const auto strEnd = str.find_last_not_of(" \t"); // Find last non-whitespace character
    const auto strRange = strEnd - strBegin + 1; // Calculate the range

    return str.substr(strBegin, strRange); // Return the trimmed string
}

// Function to load course data from a file and store it in the data structure
void loadDataStructure(const std::string& filename, std::map<std::string, Course>& courses) {
    std::ifstream file(filename); // Open the file for reading
    if (!file.is_open()) {
        std::cout << "Error: Could not open file." << std::endl; // Display error message if file couldn't be opened
        return;
    }

    std::string line;
    while (std::getline(file, line)) { // Read each line from the file
        std::vector<std::string> courseInfo = split(line, ','); // Split the line into tokens using ',' as delimiter
        if (courseInfo.size() < 2) {
            std::cout << "Error: Invalid line format. Each line must have at least two parameters." << std::endl;
            continue; // Skip processing if line format is invalid
        }

        std::string courseNumber = trim(courseInfo[0]); // Get course number and trim whitespace
        std::string courseTitle = trim(courseInfo[1]); // Get course title and trim whitespace
        std::vector<std::string> prerequisites;
        for (size_t i = 2; i < courseInfo.size(); i++) {
            prerequisites.push_back(trim(courseInfo[i])); // Get and store prerequisites for the course
        }

        // Filter courses for Computer Science (CS) or Math (MAT) courses based on course number prefix
        if (courseNumber.substr(0, 2) == "CS" || courseNumber.substr(0, 3) == "MAT") {
            courses[courseNumber] = Course(courseNumber, courseTitle, prerequisites); // Store courses in the map
        }
    }

    file.close(); // Close the file
    std::cout << "Data loaded successfully." << std::endl; // Display success message
}

// Function to print the sorted list of Computer Science department courses
void printCourseList(const std::map<std::string, Course>& courses) {
    std::vector<std::string> courseNumbers;
    for (const auto& course : courses) {
        // Filter courses for Computer Science (CS) department based on course number prefix
        if (course.first.substr(0, 2) == "CS") {
            courseNumbers.push_back(course.first); // Store CS courses in a vector
        }
    }

    std::sort(courseNumbers.begin(), courseNumbers.end()); // Sort CS course numbers alphabetically

    for (const auto& courseNumber : courseNumbers) {
        const Course& course = courses.at(courseNumber); // Get course details from the map
        std::cout << "Course Number: " << course.courseNumber << std::endl; // Print course number
        std::cout << "Course Title: " << course.courseTitle << std::endl; // Print course title
        std::cout << std::endl; // Print newline for readability
    }
}

// Function to print course information based on a given course number
void printCourseInformation(const std::string& courseNumber, const std::map<std::string, Course>& courses) {
    if (courses.count(courseNumber) == 0) {
        std::cout << "Course not found." << std::endl; // Display error if course not found in the map
        return;
    }

    const Course& course = courses.at(courseNumber); // Get course details from the map
    // Check if the course number prefix indicates Computer Science (CS) or Math (MAT) course
    if (course.courseNumber.substr(0, 2) == "CS" || course.courseNumber.substr(0, 3) == "MAT") {
        std::cout << "Course Number: " << course.courseNumber << std::endl; // Print course number
        std::cout << "Course Title: " << course.courseTitle << std::endl; // Print course title

        if (!course.prerequisites.empty()) {
            std::cout << "Prerequisites: ";
            for (const auto& prerequisite : course.prerequisites) {
                std::cout << prerequisite << " "; // Print prerequisites for the course
            }
            std::cout << std::endl;
        }
    } else {
        std::cout << "Course not found or not related to Computer Science or Math." << std::endl;
    }
}

int main() {
    std::string filename;
    std::map<std::string, Course> courses;
    bool dataLoaded = false;

    while (true) {
        std::cout << "Menu:\n";
        std::cout << "a. Load Data Structure\n";
        std::cout << "b. Print Course List\n";
        std::cout << "c. Print Course\n";
        std::cout << "d. Exit\n";
        std::cout << "Enter your choice: ";

        char choice;
        std::cin >> choice; // Read user choice
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        switch (choice) {
            case 'a': {
                std::cout << "Enter the filename: ";
                std::getline(std::cin, filename); // Read filename from user input
                loadDataStructure(filename, courses); // Load data from the file into data structure
                dataLoaded = true;
                break;
            }
            case 'b': {
                if (dataLoaded) {
                    printCourseList(courses); // Print list of CS department courses
                } else {
                    std::cout << "Error: Data structure not loaded. Please load the data first." << std::endl;
                }
                break;
            }
            case 'c': {
                if (dataLoaded) {
                    std::string courseNumber;
                    std::cout << "Enter the course number: ";
                    std::getline(std::cin, courseNumber); // Read course number from user input
                    printCourseInformation(courseNumber, courses); // Print course information
                } else {
                    std::cout << "Error: Data structure not loaded. Please load the data first." << std::endl;
                }
                break;
            }
            case 'd':
                std::cout << "Exiting program. Goodbye!" << std::endl; // Exit the program
                return 0;
            default:
                std::cout << "Invalid choice. Please try again." << std::endl; // Display error for invalid choice
                break;
        }

        std::cout << std::endl;
    }
    return 0;
}
