/*
 * CS300ProjectTwo.h
 *
 *  Created on: Dec 8, 2023
 *      Author: veronicaguzman
 *      CS 300
 */

#ifndef COURSE_MANAGER_H // Header guard to prevent multiple inclusions of the header file
#define COURSE_MANAGER_H

#include <iostream>     // Input/output stream operations
#include <fstream>      // File stream operations
#include <sstream>      // String stream operations
#include <vector>       // Vector container
#include <map>          // Map container
#include <algorithm>    // Algorithms library

class Course {
public:
    std::string courseNumber;       // String to store course number
    std::string courseTitle;        // String to store course title
    std::vector<std::string> prerequisites;   // Vector to store prerequisites

    // Constructor to initialize Course object with course number, title, and prerequisites
    Course(const std::string& number, const std::string& title, const std::vector<std::string>& prereqs);
};

std::vector<std::string> split(const std::string& str, char delimiter); // Function prototype to split a string

std::string trim(const std::string& str); // Function prototype to trim leading and trailing whitespaces

// Function prototypes to load data, print course list, and print course information
void loadDataStructure(const std::string& filename, std::map<std::string, Course>& courses);
void printCourseList(const std::map<std::string, Course>& courses);
void printCourseInformation(const std::string& courseNumber, const std::map<std::string, Course>& courses);

#endif /* COURSE_MANAGER_H */ // End of header guard and comments explaining the end of the header file

